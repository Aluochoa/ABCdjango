from django.db import models

# Create your models here.

class pro(models.Model):
    codigo= models.CharField(max_length=5)
    descripcion= models.CharField(max_length=200)
    precio= models.DecimalField(max_digits=9, decimal_places=2)
    cantidad= models.CharField(max_length=4)
    categoria= models.CharField(max_length=20)
    descripcioncategoria= models.CharField(max_length=200)
