from django.urls import path
from .views import listado_productos, create_pro, eliminar_pro

urlpatterns=[
    path('', listado_productos),
    path('new/', create_pro),
    path('eliminar_pro/<int:pro_id>/', eliminar_pro, name='eliminar_pro'),
]