from django.shortcuts import render, redirect
from .models import pro

# Create your views here.

#funcion para mostrar la pagina con el doc de html
def listado_productos(request):
    productos = pro.objects.all()
    return render(request, 'index.html', {"productos": productos})

#funcion para crear productos
def create_pro(request):
    productos= pro(codigo=request.POST['txtCodigo'], descripcion=request.POST['txtDes'], precio=request.POST['txtPre'], 
                   cantidad=request.POST['txtCant'], categoria=request.POST['txtCat'], descripcioncategoria=request.POST['txtDesCat'])
    productos.save()
    return redirect('/productos/')

def eliminar_pro(request, pro_id):
    productos= pro.objects.get(id=pro_id)
    productos.delete()
    return redirect('/productos/')



